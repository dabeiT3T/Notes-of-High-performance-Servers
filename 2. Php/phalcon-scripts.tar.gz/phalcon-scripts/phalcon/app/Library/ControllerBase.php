<?php

namespace App\Library;

use Phalcon\Mvc\Controller;

class ControllerBase extends Controller
{

}
