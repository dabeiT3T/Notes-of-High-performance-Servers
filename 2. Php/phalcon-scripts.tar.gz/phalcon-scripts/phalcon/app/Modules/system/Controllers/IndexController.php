<?php

namespace System\Controllers;

use App\Library\ControllerBase;

class IndexController extends ControllerBase
{

    public function indexAction()
    {
        
    }

}
